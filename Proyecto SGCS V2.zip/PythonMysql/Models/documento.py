class Documento:
    def __init__(self, id, Proceso, codigodocumento, NombreDocumento, Version, Estado):
        self.id = id
        self.proceso = Proceso
        self.codigodocumento = codigodocumento
        self.nombredocumento = NombreDocumento
        self.version = Version
        self.estado = Estado

    def __str__(self):
        return f"[{self.id}] {self.codigodocumento} - {self.nombredocumento} (v{self.version}) - {self.estado}"
